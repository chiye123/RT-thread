CMSIS NN Lib example arm_nnexample_gru0 for
  Cortex-M4 and Cortex-M7.

The example is configured for uVision Simulator.
